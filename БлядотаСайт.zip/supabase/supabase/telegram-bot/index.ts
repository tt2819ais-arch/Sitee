import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const TELEGRAM_BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

interface TelegramUpdate {
  message?: {
    chat: { id: number };
    text?: string;
    audio?: {
      file_id: string;
      file_name?: string;
      duration?: number;
      title?: string;
      performer?: string;
    };
    voice?: {
      file_id: string;
      duration?: number;
    };
  };
  callback_query?: {
    id: string;
    message: { chat: { id: number } };
    data: string;
  };
}

// Store user states
const userStates: Record<number, { artist: string | null }> = {};

async function sendMessage(chatId: number, text: string, replyMarkup?: object) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  const body: Record<string, unknown> = {
    chat_id: chatId,
    text: text,
    parse_mode: "HTML",
  };
  if (replyMarkup) {
    body.reply_markup = replyMarkup;
  }
  await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function answerCallbackQuery(callbackQueryId: string, text?: string) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`;
  await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      callback_query_id: callbackQueryId,
      text: text,
    }),
  });
}

async function getFile(fileId: string): Promise<{ file_path: string }> {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`;
  const response = await fetch(url);
  const data = await response.json();
  return data.result;
}

async function downloadFile(filePath: string): Promise<ArrayBuffer> {
  const url = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${filePath}`;
  const response = await fetch(url);
  return await response.arrayBuffer();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const update: TelegramUpdate = await req.json();
    console.log("Received update:", JSON.stringify(update));

    // Handle callback queries (button clicks)
    if (update.callback_query) {
      const chatId = update.callback_query.message.chat.id;
      const data = update.callback_query.data;

      if (data === "artist_maksim" || data === "artist_argot") {
        const artistName = data === "artist_maksim" ? "@MaksimXyila" : "@ar_got";
        userStates[chatId] = { artist: artistName };

        await answerCallbackQuery(update.callback_query.id, `Выбран: ${artistName}`);
        await sendMessage(
          chatId,
          `✅ Выбран артист: <b>${artistName}</b>\n\nТеперь отправьте MP3 файл с треком.`
        );
      }

      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Handle messages
    if (update.message) {
      const chatId = update.message.chat.id;

      // Handle /start command
      if (update.message.text === "/start") {
        const keyboard = {
          inline_keyboard: [
            [
              { text: "@MaksimXyila", callback_data: "artist_maksim" },
              { text: "@ar_got", callback_data: "artist_argot" },
            ],
          ],
        };

        await sendMessage(
          chatId,
          "🎵 <b>Добро пожаловать в Music Bot!</b>\n\nВыберите вкладку для загрузки трека:",
          keyboard
        );
        return new Response(JSON.stringify({ ok: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Handle audio file
      if (update.message.audio) {
        const userState = userStates[chatId];

        if (!userState?.artist) {
          const keyboard = {
            inline_keyboard: [
              [
                { text: "@MaksimXyila", callback_data: "artist_maksim" },
                { text: "@ar_got", callback_data: "artist_argot" },
              ],
            ],
          };
          await sendMessage(
            chatId,
            "⚠️ Сначала выберите артиста:",
            keyboard
          );
          return new Response(JSON.stringify({ ok: true }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        await sendMessage(chatId, "⏳ Загружаю трек...");

        try {
          // Get artist ID
          const { data: artist } = await supabase
            .from("artists")
            .select("id")
            .eq("name", userState.artist)
            .single();

          if (!artist) {
            await sendMessage(chatId, "❌ Ошибка: Артист не найден");
            return new Response(JSON.stringify({ ok: true }), {
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }

          // Download file from Telegram
          const fileInfo = await getFile(update.message.audio.file_id);
          const fileData = await downloadFile(fileInfo.file_path);

          // Generate unique filename
          const fileName = `${Date.now()}_${update.message.audio.file_name || "track.mp3"}`;

          // Upload to Supabase Storage
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from("tracks")
            .upload(fileName, fileData, {
              contentType: "audio/mpeg",
            });

          if (uploadError) {
            console.error("Upload error:", uploadError);
            await sendMessage(chatId, "❌ Ошибка при загрузке файла");
            return new Response(JSON.stringify({ ok: true }), {
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }

          // Get public URL
          const { data: publicUrlData } = supabase.storage
            .from("tracks")
            .getPublicUrl(fileName);

          // Create track record
          const trackTitle = update.message.audio.title || 
                           update.message.audio.file_name?.replace(".mp3", "") || 
                           "Без названия";

          const { error: insertError } = await supabase.from("tracks").insert({
            artist_id: artist.id,
            title: trackTitle,
            file_url: publicUrlData.publicUrl,
            duration: update.message.audio.duration,
          });

          if (insertError) {
            console.error("Insert error:", insertError);
            await sendMessage(chatId, "❌ Ошибка при сохранении трека");
            return new Response(JSON.stringify({ ok: true }), {
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }

          await sendMessage(
            chatId,
            `✅ Трек "<b>${trackTitle}</b>" успешно загружен для ${userState.artist}!`
          );

          // Reset artist selection
          userStates[chatId] = { artist: null };
        } catch (error) {
          console.error("Processing error:", error);
          await sendMessage(chatId, "❌ Произошла ошибка при обработке файла");
        }
      }
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});