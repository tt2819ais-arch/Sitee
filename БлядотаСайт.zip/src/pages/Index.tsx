//import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ArtistTabs } from "@/components/ArtistTabs";
import { TypewriterLyrics } from "@/components/TypewriterLyrics";
import { MusicPlayer } from "@/components/MusicPlayer";
import { TrackList } from "@/components/TrackList";
import { useAudioPlayer } from "@/hooks/useAudioPlayer";

interface Track {
  id: string;
  title: string;
  file_url: string;
  cover_url: string | null;
  lyrics: string | null;
  duration: number | null;
}

interface Artist {
  id: string;
  name: string;
}

const Index = () => {
  const [activeArtist, setActiveArtist] = useState("@MaksimXyila");
  const [artists, setArtists] = useState<Artist[]>([]);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showLyrics, setShowLyrics] = useState(false);

  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    progress,
    playTrack,
    togglePlayPause,
    handlePrevious,
    handleNext,
    handleSeek,
  } = useAudioPlayer(tracks);

  // Fetch artists on mount
  useEffect(() => {
    const fetchArtists = async () => {
      const { data } = await supabase.from("artists").select("*");
      if (data) {
        setArtists(data);
      }
    };
    fetchArtists();
  }, []);

  // Fetch tracks when artist changes
  useEffect(() => {
    const fetchTracks = async () => {
      setIsLoading(true);
      
      const artist = artists.find(a => a.name === activeArtist);
      if (!artist) {
        setIsLoading(false);
        return;
      }

      const { data } = await supabase
        .from("tracks")
        .select("*")
        .eq("artist_id", artist.id)
        .order("created_at", { ascending: false });

      if (data) {
        setTracks(data);
      }
      setIsLoading(false);
    };

    if (artists.length > 0) {
      fetchTracks();
    }
  }, [activeArtist, artists]);

  // Show lyrics when playing
  useEffect(() => {
    if (currentTrack && isPlaying) {
      setShowLyrics(true);
    }
  }, [currentTrack, isPlaying]);

  const handleArtistChange = (artist: string) => {
    setActiveArtist(artist);
    setShowLyrics(false);
  };

  const handleTrackSelect = (track: Track) => {
    playTrack(track);
    setShowLyrics(true);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-48">
      <ArtistTabs activeArtist={activeArtist} onArtistChange={handleArtistChange} />
      
      {showLyrics && currentTrack ? (
        <TypewriterLyrics 
          lyrics={currentTrack.lyrics} 
          currentTime={currentTime}
          duration={duration}
        />
      ) : (
        <TrackList
          tracks={tracks}
          currentTrack={currentTrack}
          onTrackSelect={handleTrackSelect}
          isLoading={isLoading}
        />
      )}

      <MusicPlayer
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        onPlayPause={togglePlayPause}
        onPrevious={handlePrevious}
        onNext={handleNext}
        progress={progress}
        currentTime={currentTime}
        duration={duration}
        onSeek={handleSeek}
      />
    </div>
  );
};

export default Index;