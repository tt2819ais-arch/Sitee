import { useState, useEffect, useRef } from "react";

interface TypewriterLyricsProps {
  lyrics: string | null;
  currentTime: number;
  duration: number;
}

export function TypewriterLyrics({ lyrics, currentTime, duration }: TypewriterLyricsProps) {
  const [displayedText, setDisplayedText] = useState("");
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  
  const lines = lyrics?.split("\n").filter(line => line.trim()) || [];
  
  // Calculate which line should be shown based on current time
  const lineInterval = duration > 0 && lines.length > 0 ? duration / lines.length : 5;
  const targetLineIndex = Math.min(Math.floor(currentTime / lineInterval), lines.length - 1);
  
  useEffect(() => {
    if (targetLineIndex !== currentLineIndex && targetLineIndex >= 0) {
      setCurrentLineIndex(targetLineIndex);
      setCharIndex(0);
      setDisplayedText("");
      setIsTyping(true);
    }
  }, [targetLineIndex, currentLineIndex]);
  
  useEffect(() => {
    if (!isTyping || !lines[currentLineIndex]) return;
    
    const currentLine = lines[currentLineIndex];
    if (charIndex < currentLine.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + currentLine[charIndex]);
        setCharIndex(prev => prev + 1);
      }, 50); // Medium typing speed
      
      return () => clearTimeout(timeout);
    } else {
      setIsTyping(false);
    }
  }, [charIndex, isTyping, currentLineIndex, lines]);
  
  if (!lyrics || lines.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center px-6">
        <p className="text-muted-foreground text-sm">Текст недоступен</p>
      </div>
    );
  }
  
  return (
    <div className="flex-1 flex items-center justify-center px-6">
      <div className="text-center max-w-sm">
        <p className={`text-xl font-medium text-glow leading-relaxed ${isTyping ? "typewriter-cursor" : ""}`}>
          {displayedText || "\u00A0"}
        </p>
      </div>
    </div>
  );
}