import { cn } from "@/lib/utils";

interface Track {
  id: string;
  title: string;
  file_url: string;
  cover_url: string | null;
  lyrics: string | null;
  duration: number | null;
}

interface TrackListProps {
  tracks: Track[];
  currentTrack: Track | null;
  onTrackSelect: (track: Track) => void;
  isLoading: boolean;
}

export function TrackList({ tracks, currentTrack, onTrackSelect, isLoading }: TrackListProps) {
  if (isLoading) {
    return (
      <div className="px-6 py-4">
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-card animate-pulse">
              <div className="w-12 h-12 rounded-lg bg-muted" />
              <div className="flex-1">
                <div className="h-4 bg-muted rounded w-3/4 mb-2" />
                <div className="h-3 bg-muted rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (tracks.length === 0) {
    return (
      <div className="px-6 py-8 text-center">
        <p className="text-muted-foreground text-sm">Треков пока нет</p>
        <p className="text-muted-foreground/60 text-xs mt-2">
          Добавьте треки через Telegram бота
        </p>
      </div>
    );
  }

  return (
    <div className="px-6 py-4">
      <div className="space-y-2">
        {tracks.map((track) => (
          <button
            key={track.id}
            onClick={() => onTrackSelect(track)}
            className={cn(
              "w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200",
              currentTrack?.id === track.id
                ? "bg-foreground/10"
                : "hover:bg-card"
            )}
          >
            {track.cover_url ? (
              <img
                src={track.cover_url}
                alt={track.title}
                className="w-12 h-12 rounded-lg object-cover"
              />
            ) : (
              <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                <span className="text-muted-foreground">♪</span>
              </div>
            )}
            <div className="flex-1 text-left min-w-0">
              <p className={cn(
                "font-medium truncate",
                currentTrack?.id === track.id && "text-foreground"
              )}>
                {track.title}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}