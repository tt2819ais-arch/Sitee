import { SkipBack, Play, Pause, SkipForward } from "lucide-react";
import { cn } from "@/lib/utils";

interface Track {
  id: string;
  title: string;
  file_url: string;
  cover_url: string | null;
  lyrics: string | null;
  duration: number | null;
}

interface MusicPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onPrevious: () => void;
  onNext: () => void;
  progress: number;
  currentTime: number;
  duration: number;
  onSeek: (e: React.MouseEvent<HTMLDivElement>) => void;
}

export function MusicPlayer({
  currentTrack,
  isPlaying,
  onPlayPause,
  onPrevious,
  onNext,
  progress,
  currentTime,
  duration,
  onSeek,
}: MusicPlayerProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  if (!currentTrack) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-player p-6 player-gradient">
        <div className="text-center text-muted-foreground text-sm">
          Выберите трек для воспроизведения
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-player player-gradient safe-area-bottom">
      <div className="px-6 pt-4 pb-8">
        {/* Progress bar */}
        <div 
          className="h-1 bg-muted rounded-full mb-4 cursor-pointer"
          onClick={onSeek}
        >
          <div 
            className="h-full bg-foreground rounded-full transition-all duration-100"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        {/* Time display */}
        <div className="flex justify-between text-xs text-muted-foreground mb-4">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
        
        {/* Track info */}
        <div className="flex items-center gap-4 mb-6">
          {currentTrack.cover_url ? (
            <img 
              src={currentTrack.cover_url} 
              alt={currentTrack.title}
              className="w-12 h-12 rounded-lg object-cover"
            />
          ) : (
            <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
              <span className="text-muted-foreground text-lg">♪</span>
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{currentTrack.title}</p>
          </div>
        </div>
        
        {/* Controls */}
        <div className="flex items-center justify-center gap-12">
          <button
            onClick={onPrevious}
            className="p-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <SkipBack size={28} />
          </button>
          
          <button
            onClick={onPlayPause}
            className="w-16 h-16 rounded-full bg-foreground text-background flex items-center justify-center hover:scale-105 transition-transform"
          >
            {isPlaying ? <Pause size={28} /> : <Play size={28} className="ml-1" />}
          </button>
          
          <button
            onClick={onNext}
            className="p-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <SkipForward size={28} />
          </button>
        </div>
      </div>
    </div>
  );
}