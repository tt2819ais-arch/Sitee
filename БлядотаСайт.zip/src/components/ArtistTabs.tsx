import { cn } from "@/lib/utils";

interface ArtistTabsProps {
  activeArtist: string;
  onArtistChange: (artist: string) => void;
}

const artists = ["@MaksimXyila", "@ar_got"];

export function ArtistTabs({ activeArtist, onArtistChange }: ArtistTabsProps) {
  return (
    <div className="flex justify-center gap-8 pt-12 pb-8">
      {artists.map((artist) => (
        <button
          key={artist}
          onClick={() => onArtistChange(artist)}
          className={cn(
            "text-lg font-medium transition-all duration-300 relative pb-2",
            activeArtist === artist
              ? "text-tab-active"
              : "text-tab-inactive hover:text-foreground/70"
          )}
        >
          {artist}
          {activeArtist === artist && (
            <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-foreground animate-fade-in-up" />
          )}
        </button>
      ))}
    </div>
  );
}
